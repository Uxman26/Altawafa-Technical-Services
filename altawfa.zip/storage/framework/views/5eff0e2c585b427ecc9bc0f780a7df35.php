<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from bookforvisa.com/about by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 24 Jul 2024 10:59:25 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon_io/favicon-16x16.png">
    <meta name="robots" content="noindex, nofollow" />
    <meta name="csrf-token" content="y3MG91A94Xume1ahBC11EkzLZ42ZWdx1PkZUHAgr" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="canonical" href="https://bookforvisa.com/about" />
    <!-- Web application manifest -->
<link rel="manifest" href="https://bookforvisa.com/pwa/manifest">
<!-- Theme color for chrome on android -->
<meta name="theme-color" content="#0062ff">
<!-- Add to homescreen for chrome on android -->
<meta name="mobile-web-app-capable" content="yes">
<meta name="application-name" content="BookForVisa">
<link rel="icon" sizes="512x512" href="https://bookforvisa.com/pwa/assets/images/icons/icon-512x512.png">
<!-- Add to homescreen for safari on ios -->
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-title" content="BookForVisa">
<link rel="apple-touch-icon" href="https://bookforvisa.com/pwa/assets/images/icons/icon-512x512.png">
<!-- Splashes for safari on ios -->
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-640x1136.png" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-750x1334.png" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-1242x2208.png" media="(device-width: 621px) and (device-height: 1104px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-1125x2436.png" media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-828x1792.png" media="(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-1242x2688.png" media="(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-1536x2048.png" media="(device-width: 768px) and (device-height: 1024px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-1668x2224.png" media="(device-width: 834px) and (device-height: 1112px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-1668x2388.png" media="(device-width: 834px) and (device-height: 1194px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="https://bookforvisa.com/pwa/assets/images/icons/splash-2048x2732.png" media="(device-width: 1024px) and (device-height: 1366px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<!-- Tile for Win8 -->
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="https://bookforvisa.com/pwa/assets/images/icons/icon-512x512.png">
<!-- Register serviceworker -->
<script src="https://bookforvisa.com/register-serviceworker"></script>
    <title>About Page</title>
	   <meta name="description" content="About Page">
       <meta name="keywords" content="About Page">
       <meta name="author" content="BookForVisa">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <meta name="twitter:card" content="summary">
<meta name="twitter:site" content="BookForVisa">
<meta name="twitter:title" content="BookForVisa">
<meta name="twitter:description" content="you can get all the reservations you need in a matter of few minutes. You can get reservations for flight & hotel to any destinations or countries instantly, even while you are at the embassy. These reservations are acceptable for visa application to any country.">
<meta name="twitter:creator" content="@author_handle">
<meta name="twitter:image" content="https://bookforvisa.com/assets_newdesign/img/logo.png">

<meta property="og:title" content="BookForVisa" />
<meta property="og:type" content="article" />
<meta property="og:url" content="https://bookforvisa.com" />
<meta property="og:image" content="https://bookforvisa.com/assets_newdesign/img/logo.png" />
<meta property="og:image:width" content="450"/>
<meta property="og:image:height" content="298"/>
<meta property="og:description" content="you can get all the reservations you need in a matter of few minutes. You can get reservations for flight & hotel to any destinations or countries instantly, even while you are at the embassy. These reservations are acceptable for visa application to any country." />
<meta property="og:site_name" content="BookForVisa" />
<meta property="fb:admins" content="Facebook numeric ID" />
    <link rel="icon" href="https://bookforvisa.com/assetsimg/Fevicon.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/linericon/style.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/owl-carousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/flat-icon/font/flaticon.css">
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/vendors/nice-select/nice-select.css">
    <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/3.0.3/daterangepicker.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/scss/aos-animation.css" />
    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/scss/style.css" />
    <link rel="stylesheet" type="text/css" href="https://bookforvisa.com/assets_newdesign/scss/mystyle.css" />
    <link href="https://bookforvisa.com/assets_newdesign/vendors/typeahead/jquery.typeahead.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://bookforvisa.com/assets/css/custom.css" />

    <link rel="stylesheet" href="https://bookforvisa.com/assets_newdesign/uikit/css/uikit.min.css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css" rel="stylesheet">

    <meta name="google-site-verification" content="6LoUt64boTB87hjfhf2W4IOA10py6anfCGeSFSfZCJY" />
    <style>
    </style>
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '838128213487562');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=838128213487562&amp;ev=PageView&amp;noscript=1" /></noscript>

    <script>window['gtag_enable_tcf_support'] = true</script>

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-MDZW4LR');
    </script>
    <!-- End Google Tag Manager -->


</head>

<body class="bg-shape layout_about">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MDZW4LR" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div style="display: none" class="divLoading"></div>

    <!--================ Header Menu Area start =================-->

<header class="header_area">

    <div class="main_menu">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container box_1620">
                <a class="navbar-brand logo_h" href="https://bookforvisa.com/"><img src="https://bookforvisa.com/assets_newdesign/img/logo.png" alt=""></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <button type="button" class="border-0 currency-btn" style="background: transparent;    white-space: nowrap;" data-toggle="modal" data-target="#currencymodal">
                    <span class="leftbtn"><span class="flag-icon flag-icon- flag-icon-squared"></span></span> <span class="madal-btn">  </span>
                 </button>
                <div class="collapse navbar-collapse offset" id="navbarSupportedContent">

                    <ul class="nav navbar-nav menu_nav justify-content-end">
                        <li class="nav-item "><a class="nav-link" href="https://bookforvisa.com/">Home</a></li>
                        <li class="nav-item active"><a class="nav-link" href="https://bookforvisa.com/about">About Us</a></li>
                        <li class="nav-item "><a class="nav-link" href="https://bookforvisa.com/faq">FAQ</a></li>
                        <li class="nav-item "><a class="nav-link" href="https://bookforvisa.com/articles">Blog</a></li>

                        <li class="nav-item "><a class="nav-link" href="https://bookforvisa.com/contact">Contact</a></li>

                                                    <li class="nav-item"><a class="nav-link" href="https://bookforvisa.com/login">Login</a></li>
                                            </ul>
                </div>
            </div>
        </nav>
    </div>
</header>

<header class="mobile__menu_offcanvas">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="nav_holder_wrapper">
                <div class="web___main__logo">
                    <a class="" href="https://bookforvisa.com/"><img src="https://bookforvisa.com/assets_newdesign/img/logo.png" alt=""></a>
                </div>
                <button type="button" class="border-0 currency-btn" style="background: transparent;    white-space: nowrap;" data-toggle="modal" data-target="#currencymodal">
                    <span class="leftbtn"><span class="flag-icon flag-icon- flag-icon-squared"></span></span> <span class="madal-btn">  </span>
                 </button>
                <div class="offcanvas___menu_call">
                    <a href="#my-id" uk-toggle><i class="fa fa-bars" aria-hidden="true"></i></a>

                    <div class="offcanvas__area">
                        <div id="my-id" uk-offcanvas="overlay: true;flip:true">
                            <div class="uk-offcanvas-bar">

                                <button class="uk-offcanvas-close" type="button" uk-close></button>


                                <div class="offcanvas___menu_wrapper">
                                    <!-- <div class="uk-width-1-2@s uk-width-2-5@m"> -->
                                        <ul class="uk-nav-default uk-nav-parent-icon" uk-nav>

                                            <!-- <div class="profile__img">
                                                    <img src="https://bookforvisa.com/assets_newdesign/img/about/about-media.png">
                                                </div> -->

                                                                                        <li><a href="https://bookforvisa.com/login">Login</a></li>

                                            <li class=""><a href="https://bookforvisa.com/" class="active___color">Home</a></li>
                                            <li class="active"><a href="https://bookforvisa.com/about">About Us</a></li>
                                            <li class=""><a href="https://bookforvisa.com/faq">FAQ</a></li>
                                            <li class=""><a href="https://bookforvisa.com/articles">Blog</a></li>
                                            <li class=""><a href="https://bookforvisa.com/contact">Contact</a></li>

                                        </ul>

                                        <div class="footer__content">
                                            <p><a href="https://bookforvisa.com/">bookforvisa</a> All Right Reserved</p>
                                        </div>
                                    <!-- </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</header>
<!--================Header Menu Area =================-->


<!-- home page currency madal start -->

<div class="modal fade" id="currencymodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg main-modal-div">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Currency Picker</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">  <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="fixed-div" style="padding: 20px">
                <div class="typeahead__container" style="width: 100%;">
                    <div class="typeahead__field">
                        <div class="typeahead__query">
                            <input class="js-typeahead-french_v1" name="french_v1[query]" placeholder="Search"
                                autocomplete="off">
                        </div>
                        <div class="typeahead__button">
                            <button type="submit">
                                <i class="typeahead__search-icon"></i>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-body">
                <div id="currencybox" class="currency-modal-list-items">


                        <div class="currency-modal changecurrency "
                            data-curr_code="AUD_$" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-au flag-icon-squared"></span>
                                <span class="country-name">AUD - </span>
                                <span class="currency">$</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">Australia</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="CAD_$" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-ca flag-icon-squared"></span>
                                <span class="country-name">CAD - </span>
                                <span class="currency">$</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">Canada</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="CNY_¥" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-cn flag-icon-squared"></span>
                                <span class="country-name">CNY - </span>
                                <span class="currency">¥</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">China</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="EUR_€" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-eu flag-icon-squared"></span>
                                <span class="country-name">EUR - </span>
                                <span class="currency">€</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">European Union</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="INR_₹" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-in flag-icon-squared"></span>
                                <span class="country-name">INR - </span>
                                <span class="currency">₹</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">India</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="SGD_$" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-sg flag-icon-squared"></span>
                                <span class="country-name">SGD - </span>
                                <span class="currency">$</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">Singapore</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="THB_฿" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-th flag-icon-squared"></span>
                                <span class="country-name">THB - </span>
                                <span class="currency">฿</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">Thailand</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="AED_د.إ" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-ae flag-icon-squared"></span>
                                <span class="country-name">AED - </span>
                                <span class="currency">د.إ</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">United Arab Emirates</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="GBP_£" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-gb flag-icon-squared"></span>
                                <span class="country-name">GBP - </span>
                                <span class="currency">£</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">United Kingdom</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                        <div class="currency-modal changecurrency "
                            data-curr_code="USD_$" >
                            <div class="currency-modal-list-item-line-one">
                                <span
                                    class="flag-icon flag-icon-us flag-icon-squared"></span>
                                <span class="country-name">USD - </span>
                                <span class="currency">$</span>
                            </div>
                            <div class="currency-modal-list-item-line-two">
                                <span class="full-country">United States</span>
                            </div>
                            <span class=" currency-modal-list-item-tick"></span>
                        </div>

                </div>

            </div>
            <div class="currency-modal-footer">
                <i id="scroll_currency" class="arrow-icon down"></i>
            </div>
        </div>
    </div>
</div>

<!-- home page currency madal exit -->



<section>
  <div class="hearo-banner mb-3">
    <img src="https://bookforvisa.com/assets_newdesign/img/about/banner.png" class="img-fluid">
  </div>
</section>

<section class="pt-3 pb-3">
  <div class="container">
    <div class="section-intro text-center">
    <img class="section-intro-img" src="https://bookforvisa.com/assets_newdesign/img/home/section-icon.png" alt="">
      <p>We aims to make the process of meeting your visa requirements simpler, faster and affordable. We assist with recognized flight and hotel reservations for the application of a visa when planning international travel. Most embassy encourage travelers against the purchase of full airline tickets or securing accommodation before their visa is approved. This is to minimize your lost in the case if the embassy refuse your application.</p>
    </div>
  </div>
</section>


<!--================About Area Start =================-->
<section class="bg-gray about-media py-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-5 col-md-5">
        <img class="img-fluid" src="https://bookforvisa.com/assets_newdesign/img/about/about-media.png" alt="">
      </div>
      <div class="col-lg-7 col-md-7 align-self-center about-content">
        <h2 class="underline">What We Believe</h2>
        <p>Regardless of where you are from, we take the confusion out of finding a reservation for your visa application needs. We go as far as guaranteeing efficient reservations to ensure a smooth and convenient experience. As many people are under the misconception that an airplane ticket and hotel booking must be secured when applying for a Visa. The truth is that numerous embassies will accept a flight and hotel reservations without the need to provide a full paid ticket or booking accommodation.</p>
        <p>Based on our experience and our expertise in the travel industry, we issue a flight or hotel reservation document that is acceptable by a visa consulate or an embassy. Through our booking process and the issuing of the relevant documentation, we can help you avoid the costs and the inconvenience of paying for a full flights and accommodation before your visa is approved. Only once visa approval is received, will you proceed with your new arrangement for a full flight ticket and hotel booking.</p>
        <p>If you are in the process of applying for a visa and need a recognized reservation, we are your trusted provider of flight and hotel reservations.</p>
      </div>
    </div>
  </div>
</section>
<!--================About Area End =================-->



<section class="pt-3 pb-3">
  <div class="container">
    <div class="section-intro text-center pb-0 our-mission">
      <h2 class="underline">Our Mission</h2>
      <p>We provide acceptable and affordable flight and hotel reservations for visa application purposes. Our aim is to deliver a premium standard of support to assist travelers with flight, hotel and their trip plans requirements. We strive to provide efficient, easy and professional travel solutions our customers can always depend on.</p>
    </div>
  </div>
</section>



    <!-- ================ start footer Area ================= -->
<style>

    .follow_us {
        margin-top: 15px;
        animation-delay: 1.1s;
        -webkit-animation-delay: 1.1s;
        -moz-animation-delay: 1.1s
    }

    .follow_us h5 {
        color: #fff
    }

    .follow_us ul li {
        display: inline-block;
        margin-right: 10px;
        font-size: 20px;
        font-size: 1.25rem
    }

    .follow_us ul li:first-child {
        color: #fff;
        text-transform: uppercase;
        font-weight: 500;
        letter-spacing: 2px;
        font-size: 13px;
        font-size: 0.8125rem
    }

    .follow_us ul li a {
        color: #fff;
        opacity: 0.7
    }

    .follow_us ul li a:hover {
        opacity: 1
    }

    ul#footer-selector {
        margin: 0 0 0 0;
        padding: 0;
        list-style: none
    }

    ul#footer-selector li {
        float: left;
        margin-right: 10px
    }

    @media (max-width: 575px) {
        ul#footer-selector li:last-child {
            margin-top: 5px
        }
    }

    ul#additional_links {
        margin: 0;
        padding: 8px 0 0 0;
        color: #555;
        font-size: 13px;
        font-size: 0.8125rem;
        float: right
    }

    @media (max-width: 991px) {
        ul#additional_links {
            float: none;
            margin-top: 10px
        }
    }

    ul#additional_links li {
        display: inline-block;
        margin-right: 15px
    }

    ul#additional_links li:first-child {
        margin-right: 20px
    }

    ul#additional_links li:last-child:after {
        content: ""
    }

    ul#additional_links li span {
        color: #fff;
        opacity: 0.5
    }

    ul#additional_links li a {
        color: #fff;
        opacity: 0.5;
        -moz-transition: all 0.3s ease-in-out;
        -o-transition: all 0.3s ease-in-out;
        -webkit-transition: all 0.3s ease-in-out;
        -ms-transition: all 0.3s ease-in-out;
        transition: all 0.3s ease-in-out
    }

    ul#additional_links li a:hover {
        opacity: 1
    }

    ul#additional_links li:after {
        content: "|";
        font-weight: 300;
        position: relative;
        left: 10px
    }

</style>
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 p-r-5">
                <div class="single-footer-widget">
                    <h4>BookForVisa</h4>
                    <p>
                        You can get all the reservations you need in a matter of few minutes. You can get reservations for flight &amp; hotel to any destinations or countries instantly, even while you are at the embassy. These reservations are acceptable for visa application to any country.
                    </p>
                </div>
            </div>

            <!-- <div class="col-lg-3 col-md-6 ml-lg-auto width___for_mobile">
                <div class="single-footer-widget text-left">
                    <h4>Navigation</h4>
                    <div class="row">
                        <div class="col">
                            <ul class="footer__normal_nav">
                                <li><a href="https://bookforvisa.com">Home</a></li>
                                <li><a id="pricing-link" href="https://bookforvisa.com/#pricingtable">Pricing</a></li>
                                <li><a href="https://bookforvisa.com/flight">Flight</a></li>
                                <li><a href="https://bookforvisa.com/hotel">Hotel</a></li>
                                <li><a href="https://bookforvisa.com/contact">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <h4>Contact Us</h4>
                    <div class="row">
                        <div class="col">
                            <ul class="footer__normal_nav">


                                <li> <i class="fa fa-location-arrow"></i>

                                    <p  style="display: inline-flex;vertical-align: top;">99 Wall Street #09 New York, NY 10005
                                    </p>
                                </li>

                                <li><i class="fa fa-envelope"></i>support@bookforvisa.com</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <div class="footer-bottom">
        <div class="align-items-center container">

            <div class="row">
                <div class="col-lg-6">
                    <ul id="footer-selector">

                        <li><img src="https://bookforvisa.com/assets_newdesign/img/all_cards.svg" alt="">
                            <img style="width: 117px !important; margin-left: -44px;" src="https://bookforvisa.com/assets/img/invoice/payment-stripe.jpg" alt="">
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul id="additional_links">
                        <li><a href="https://bookforvisa.com/terms">Terms and conditions</a></li>
                        <li><a href="https://bookforvisa.com/policy">Privacy</a></li>
                        <li><span>© <script>
                    document.write(new Date().getFullYear());
                </script>  BookForVisa</span></li>
                    </ul>
                </div>
            </div>
        </div>


    </div>
</footer>
<!-- ================ End footer Area ================= -->

<div class="modal fade bd-example-modal-lg" id="videoModal" tabindex="-1" role="dialog"
     aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="position: relative;">
            <!-- <div class="modal-header"> -->
        <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
        <div style="position: absolute;top: 20px;right: 20px;z-index: 99;">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="opacity: 1;">
                <span aria-hidden="true"><img src="https://bookforvisa.com/assets_newdesign/img/cancel.png" style="width: 24px;"></span>
            </button>
        </div>


            <div itemscope itemtype="https://schema.org/VideoObject">
                <meta itemprop="uploadDate" content="Thu Apr 14 2023 12:45:54 GMT+0530 (Indian Standard Time)"/>
                <meta itemprop="name" content="Bookforvisa"/>
                <meta itemprop="description" content="If you have plan to travel abroad, you might need an entry visa from the embassy of the destination country you plan to visit. To obtain this visa, you need to submit a visa application"/>
                <meta itemprop="duration" content="P0Y0M0DT0H1M29S"/>
                <meta itemprop="thumbnailUrl" content="https://content.jwplatform.com/thumbs/4gDCMqxl-1920.jpg"/>
                <meta itemprop="contentUrl" content="https://content.jwplatform.com/videos/4gDCMqxl-bryimXIT.mp4"/>
                <div style="position:relative; overflow:hidden; padding-bottom:56.25%">
                    <iframe id="video-iframe" src="https://cdn.jwplayer.com/players/4gDCMqxl-UwMgkB3Z.html" width="100%" height="100%"
                            frameborder="0" scrolling="auto" title="Bookforvisa" style="position:absolute;"
                            allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade drawer right-align" id="pwaModalRight" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="pwaModalLabel">Install BookForVisa App</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="btnpwainstall">Install Now</button>
      </div>
    </div>
  </div>
</div>



<input type="hidden" id="login_url" value="https://bookforvisa.com/login">



    <script src="https://bookforvisa.com/assets_newdesign/vendors/jquery/jquery-3.2.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.7/dist/loadingoverlay.min.js">
    </script>


    <script>
        window.onbeforeunload = function(e) {
            $.LoadingOverlay('show');
        }


        $.LoadingOverlaySetup({

            image: `https://bookforvisa.com/assets/img/loader.gif`,
            imageAnimation: "none",
            maxSize: "300",
            imageColor: "none"

        });


        //$.LoadingOverlay('show');


        function factor(elemA, elemB, prop) {
            //This method returns a DOMRect object with eight properties:
            const sizeA = elemA.getBoundingClientRect()[prop];
            const sizeB = elemB.getBoundingClientRect()[prop];
            console.log(sizeB / sizeA)
            return (sizeB / sizeA)
        }
        const height = (elem) => {
            return elem.getBoundingClientRect().height
        }

        const distance = (elemA, elemB, prop) => {
            const sizeA = elemA.getBoundingClientRect()[prop];
            const sizeB = elemB.getBoundingClientRect()[prop];
            return (sizeB - sizeA)
        }

        document.querySelectorAll('.card___main_holder').forEach(i => {
            const head = i.querySelector('.card__head')
            const image = i.querySelector('.card__image')
            const author = i.querySelector('.card__author')
            const body = i.querySelector('.card__body')
            const foot = i.querySelector('.card__foot')

            console.log(head.getBoundingClientRect())

            //using event handlers instead of event listeners
            i.onmouseenter = () => {
                console.log('mouse enter')
                i.classList.add('hover') //text white color & bg blue
                //we haven't added yet but we will get that in a second

                //now the bg scale
                const imageScale = 1 + factor(head, body, 'height')
                image.style.transform = `scale(${imageScale})`;

                //body moving up
                const bodyDistance = height(foot) * -1
                body.style.transform = `translateY(${bodyDistance}px)`

                //head mobing up
                const authorDistance = distance(head, author, 'height')
                author.style.transform = `translateY(${authorDistance}px)`;
            }
            i.onmouseleave = () => {
                console.log('mouse leave')
                i.classList.remove('hover');
                //re-start the transform property
                image.style.transform = 'none';
                body.style.transform = 'none';
                author.style.transform = 'none';
            }
        })
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/vendors/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/vendors/nice-select/jquery.nice-select.min.js"></script>

    <!-- Accord Js -->
    <script src="https://bookforvisa.com/assets_newdesign/js/myjs.js"></script>

    <script src="https://bookforvisa.com/assets_newdesign/js/jquery.ajaxchimp.min.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/js/mail-script.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/js/main.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/js/aos-animation.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/js/show-pdf-plugin.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/uikit/js/uikit.min.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/uikit/js/uikit-icons.min.js"></script>
    <script src="https://bookforvisa.com/assets_newdesign/vendors/typeahead/jquery.typeahead.min.js"></script>
    <script src="http://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.3/js.cookie.min.js"></script>

    <script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.24/moment.min.js"></script>
    <script type="text/javascript"
        src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/3.0.3/daterangepicker.min.js"></script>

    <script>

$(document).on('click', '.changecurrency', function() {
        $value = $(this).find(".full-country").text();
        window.location.href = "https://bookforvisa.com/currency/" + $value.split(" ").join("-").toLowerCase()
    });

    $.typeahead({
        input: '.js-typeahead-french_v1',
        minLength: 0,
        maxItem: 5,
        order: "asc",
        hint: true,
        accent: true,
        searchOnFocus: true,
        callback: {
            onClickAfter: function(param1, param2, node, a, item, event) {

                let contry = node.country.toLowerCase();
                window.location.href = "https://bookforvisa.com/currency/" + contry.split(" ").join("-");
                return false;
            },

        },
        template: function(query, item) {
            return '<span class="flag-icon flag-icon-' + item.code.slice(0, 2) +
                ' flag-icon-squared"></span> ' + item.country + '(' + item.symbol + ')';
        },
        emptyTemplate: "No Result Found",
        display: ["code", "country", "symbol"],
        backdrop: {
            "background-color": "#3879d9",
            "opacity": "0.1",
            "filter": "alpha(opacity=10)"
        },
        source: {
            ab: "https://bookforvisa.com/get-country"
        },
        debug: true
    });
    </script>
    <script>
          let imagurl = "https://bookforvisa.com/assets";
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
    $(".after-class-end").on("click", function() {
            $("#videoModal").modal("show");
            $('#video-iframe').attr('src', "https://cdn.jwplayer.com/players/4gDCMqxl-UwMgkB3Z.html");
        });
        $('#videoModal').on('show.bs.modal', function() {
            // $("#videoModal iframe").attr("src", videoSrc + "&amp;autoplay=1&loop=1");
            $(".w-big-play-button").trigger("click");
            // console.log(videoSrc);
        });
        $('#videoModal').on('hidden.bs.modal', function() {
            // $("#videoModal iframe").attr("src", null);
        });

        function formatState(state) {
            if (!state.id) {
                return state.text;
            }

            var baseUrl = "https://lipis.github.io/flag-icon-css/flags/4x3/";
            var $state = $(
                '<span><img class="img-flag" /> <span></span></span>'
            );

            // Use .text() instead of HTML string concatenation to avoid script injection issues
            $state.find("span").text(state.text);
            $state.find("img").attr("src", baseUrl + "/" + state.element.value.toLowerCase() + ".svg");

            return $state;
        };

        // show password
        $(document).ready(function() {
            $('#showpass').click(function() {
                $(this).is(':checked') ? $('#password').attr('type', 'text') : $('#password').attr('type',
                    'password');
            });
            $('[data-toggle="tooltip"]').tooltip();
            $(".countries").select2({
                templateSelection: formatState
            });
            setInterval(setCookie, 15000);
        });

        AOS.init({
            duration: 1600,
        })

        function setCookie() {
            var $cookie = Cookies.get('visitors');
            if (!$cookie) {
                var $value = Math.random().toString(36).substr(2, 9);
                Cookies.set('visitors', $value, {
                    expires: 365
                });
                $.ajax({
                    type: "GET",
                    url: "https://bookforvisa.com/add-visitor-count" + '/' + $value,
                    success: function(data) {
                        // console.log(data);
                    }
                });
            } else {
                $.ajax({
                    type: "GET",
                    url: "https://bookforvisa.com/update-visitor-status" + '/' + $cookie,
                    success: function(data) {
                        // console.log(data);
                    }
                });
            }
        }
    </script>


    <!-- To show Loader for login Btn -->
    <script type="text/javascript">

    </script>



    <script type="text/javascript">
        let deferredPrompt; // Variable should be out of scope of addEventListener method

        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault(); // This prevents default chrome prompt from appearing

            deferredPrompt = e; // Save for later

           //showInAppInstallPromotion();
        });
        window.addEventListener('appinstalled', () => {

            // Hide the app-provided install promotion
            hideInstallPromotion();
            // Clear the deferredPrompt so it can be garbage collected
            deferredPrompt = null;
            // Optionally, send analytics event to indicate successful install
            console.log('PWA was installed');
        });



        $('#videoModal').on('hidden.bs.modal', function(e) {
            $('#video-iframe').attr('src', null);
        })
    </script>

</body>


<!-- Mirrored from bookforvisa.com/about by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 24 Jul 2024 10:59:26 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\booking\resources\views/about.blade.php ENDPATH**/ ?>