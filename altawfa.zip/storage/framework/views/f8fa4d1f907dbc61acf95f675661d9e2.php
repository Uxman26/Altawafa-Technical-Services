<?php $__env->startSection('section'); ?>
    <style>
        .login-container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 500px;
            text-align: center;
            margin-left: auto;
            margin-right: auto;
        }

        .login-container h2 {
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
    </style>
    <!-- ================ Login section start ================= -->
    <div id="main" class="main-section">
        <div id="fullwidth" class="main-fullwidth main-col-full">
            <section class="wpb-content-wrapper">
                <div class="login-container">
                    <h2>Update Profile</h2>
                    <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-danger">
                            <span><?php echo e($message); ?></span>
                        </div>
                        <?php elseif($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('update_profile')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" value="<?php echo e(auth()->user()->name); ?>" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" value="<?php echo e(auth()->user()->email); ?>" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Update Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="number">Phone Number</label>
                            <input type="text" id="number" value="<?php echo e(auth()->user()->number); ?>" name="number" required>
                        </div>
                        <div class="form-group">
                            <label for="contact_email">Contact Email</label>
                            <input type="contact_email" id="contact_email" value="<?php echo e(auth()->user()->contact_email); ?>" name="contact_email" required>
                        </div>
                        <button type="submit" style="color: white">Update</button>
                    </form>
                </div>
            </section>
        </div>
    </div>


    <!-- ================ Login section end ================= -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\altawfa\resources\views/auth/profile.blade.php ENDPATH**/ ?>